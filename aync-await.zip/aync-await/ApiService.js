const posts = (searchWord)=> fetch(`https://dummyjson.com/posts/search?q=${searchWord}`)
 .then((response) => { return response.json()});
 //.then((jsonreponse) => {return jsonreponse.posts;});

export default posts;

