import { useState } from "react";
import SearchComponent from "./Components/SearchComponent";
import posts from "./Services/ApiService";

function App() {
const [postList,setPostList]=useState([]);
  // const handleSearch =  (searchWord) => {
  //   console.log('Accessing state of Search in parent (App.js): ' + (searchWord));
 
  //   posts(searchWord).then((response) => { 
  //     console.log(response);
  //     return response.json();
  //   })
  //   .then((jsonreponse) => {console.log(jsonreponse.posts);});
  // };

  const handleSearch= async(searchWord)=>{
    
    const results= await posts(searchWord);//.then((response) =>{return  response.json()});
console.log('ok: '+  JSON.stringify(results));
 };
  return (
    <div className="App">
      <SearchComponent onSearchSubmit={handleSearch} />
    </div>
  );
}

export default App;
