import {configureStore, createSlice} from '@reduxjs/toolkit';

const coursesSlice=createSlice({
	name:'course',
	initialState:[],
	reducers:{
		addCourse(state,action){
			state.push(action.payload);
		},
		removeCourse(state,action){
		
		},
	}
});


const store=configureStore({
	reducer:{
		courses:coursesSlice.reducer
	}

});
export {store};
export const {addCourse}=coursesSlice.actions;
// const startingState=store.getState();
// console.log(startingState);

// store.dispatch({
//     type:"course/addCourse",
//     payload:"science"
//     });



//     const afterState=store.getState();
//     console.log(afterState);

//     store.dispatch(coursesSlice.actions.addCourse("math"))
//     const afterState1=store.getState();
//     console.log(afterState1);