import logo from './logo.svg';
import './App.css';
import {useDispatch,useSelector} from 'react-redux'
import {addCourse,store } from './store'

import { createRandomWord } from "./data";
function App() {
  const dispatch=useDispatch();
  const courselist = useSelector((state)=>{
    return state.courses;
    });
  const handleCourseAdd = (course) => {
console.log(course);
dispatch(addCourse(course));
console.log(store.getState());
  };
  const handleCourseRemove = (course) => {

  };

  const renderedCourses = courselist.map((course) => {
    return (
      <li key={course}>
        {course}
        <button
          onClick={() => handleCourseRemove(course)}
          className="button is-danger"
        >
          X
        </button>
      </li>
    );
  });

  return (
    <div className="content">
      <div className="table-header">
        <h3 className="subtitle is-3">Test heade</h3>
        <div className="buttons">
          <button
            onClick={() => handleCourseAdd(createRandomWord())}
            className="button is-link"
          >
            + Add 
          </button>
        </div>
      </div>
      <ul>{renderedCourses}</ul>
    </div>
  );
}


export default App;
