import { Outlet, Link } from "react-router-dom";

const Layout2 = () => {
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to="/">Settings</Link>
          </li>
          <li>
            <Link to="/blogs">Users</Link>
          </li>
          <li>
            <Link to="/contact">Reset</Link>
          </li>
        </ul>
      </nav>

      <Outlet />
    </>
  );
};

export default Layout2;
