import Link from "./components/link";
import About from "./pages/about";

import Blogs from "./pages/blogs";
import Contact from "./pages/contact";
import NoPage from "./pages/nopage";
import Route from "./components/route";

function App() {
  return <div>
    <div>
      <Link to="/contactus">Contact Us</Link>
      <Link to="/blogs">Blogs</Link>
      {/* <a href="/contactus">Contact US </a>
      <a href="/blogs">Blogs</a> */}
    </div>
    <div>
      <Route path="/about">
        <About />
      </Route>
      <Route path="/contactus">
        <Contact />
      </Route>
      <Route path="/blogs">
        <Blogs />
      </Route>
    </div>
  </div>
}

export default App;