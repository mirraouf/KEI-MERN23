import { useState } from "react";
import CreatePostComponent from "./Components/CreatePostComponent";
import ListPostsComponent from "./Components/ListPostsComponent";
import SearchComponent from "./Components/SearchComponent";
import posts from "./Services/ApiService";

function App() {
  const [postList, setPostList] = useState([]);

  const [posts, setPosts] = useState([]);


  const handleSearch = async (searchWord) => {
    const results = await posts(searchWord);//.then((response) =>{return  response.json()});
    console.log('ok: ' + JSON.stringify(results));
  };

  const addPost = (title, bodyText) => {
    console.log(title, bodyText);
    const updatedPosts = [
      ...posts, { id: Math.round(Math.random() * 9999), title: title, body: bodyText }
    ];
    
    setPosts(updatedPosts);
  }
  const deletePost = (id) => {
    const updatedPosts = posts.filter((post) => {
      return post.id != id;
    });
    setPosts(updatedPosts);
  };
  
  const editPost = (id, body) => {
    console.log("Eidt app");
  };

  return (
    <div className="App">
      <SearchComponent onSearchSubmit={handleSearch} />

      <CreatePostComponent onAdd={addPost} />

      <ListPostsComponent posts={posts} onDelete={deletePost} onEdit={editPost}/>
    </div>
  );
}

export default App;
