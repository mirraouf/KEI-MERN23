import { useState } from "react";

function EditCardComponent(onEdit){
    const [bodyText, setBodyText]=useState('');
    const handleChange=(e)=>{
        setBodyText(e.target.value);

    };

    const  handleSubmit=(e)=>{
        e.preventDefault();
        onEdit(123,bodyText);
    }
return (
    <div>

        <form  onSubmit={handleSubmit}>
            <label>Body</label>
            <input value={bodyText} onChange={handleChange} />
            <button>Update</button>
        </form>

    </div>
);
}
export default EditCardComponent;