import { useState } from "react";

function SearchComponent({onSearchSubmit}) {
    const [searchWord, setSearchWord] = useState('');

    const handleInputChange = (e) => {
        setSearchWord(e.target.value);
        console.log('Stste Changed');
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();
        console.log('Form Submit ');
        onSearchSubmit(searchWord);
    };

    return (
        <div>
            <form onSubmit={handleFormSubmit}> 
                <input value={searchWord}  onChange={handleInputChange}/>
            </form>

        </div>

    );
}

export default SearchComponent;