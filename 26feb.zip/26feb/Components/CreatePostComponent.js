import { useState } from "react";

function CreatePostComponent({onAdd}) {
    const [title, setTitle] = useState('');
    const [bodyText, setBodyText] = useState('');

    const handleTitleChange = (event) => {
        setTitle(event.target.value);
    }
    const handleBodyChange = (event) => {
        setBodyText(event.target.value);
    }

    const handleSubmit=(e)=>{
        e.preventDefault();
        onAdd(title,bodyText);
    };

    return (<div style={{backgroundColor:'grey'}}>
        <form onSubmit={handleSubmit}>
            <label>Title</label>
            <input value={title} onChange={handleTitleChange} />
            <label>Body</label>
            <input value={bodyText} onChange={handleBodyChange} />
            <button>Add</button>
        </form>
    </div>
    );

}

export default CreatePostComponent;