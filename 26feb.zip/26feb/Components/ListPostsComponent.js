import CardComponent from "./CardComponent";


function ListPostsComponent({posts, onDelete,onEdit}){
const renderedPosts=posts.map((post)=>{
    return <CardComponent key={post.id} post={post} onDelete={onDelete} onEdit={onEdit}/>
});

    return(
        <div>{renderedPosts}</div>
    );
}
export default ListPostsComponent;